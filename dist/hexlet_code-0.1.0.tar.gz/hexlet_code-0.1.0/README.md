### Hexlet tests and linter status:
[![Actions Status](https://github.com/ShelbaSK/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ShelbaSK/python-project-49/actions)
### Maintainability Badge from CodeClimate
[![Maintainability](https://api.codeclimate.com/v1/badges/5e44080d71362322eec0/maintainability)](https://codeclimate.com/github/ShelbaSK/python-project-49/maintainability)
### asciinema brain-even
[![asciicast](https://asciinema.org/a/8TzYxkx2Ps7WnRBq7eT21xLBU.svg)](https://asciinema.org/a/8TzYxkx2Ps7WnRBq7eT21xLBU)
### asciinema brain-calc
[![asciicast](https://asciinema.org/a/19iU3QCxIn4pfhPO5iXGUFGfm.svg)](https://asciinema.org/a/19iU3QCxIn4pfhPO5iXGUFGfm)
### asciinema brain-gcd
[![asciicast](https://asciinema.org/a/QiWb9dz5UtPnoedC4rt7vytpj.svg)](https://asciinema.org/a/QiWb9dz5UtPnoedC4rt7vytpj)