#!/usr/bin/env python3

def greetings():
    print('Welcome to the Brain Games!')

def main():
    greetings()

if __name__ == '__main__':
    main()